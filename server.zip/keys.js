module.exports={
    JWT_SECRET:"allasdashboard"
}